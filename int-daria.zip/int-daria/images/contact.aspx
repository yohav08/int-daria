<%@ Page Language="C#" AutoEventWireup="true" CodeFile="contact.aspx.cs" Inherits="Contact" %>

<!DOCTYPE html>
<html>
<head>
    <title>Contacto</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/css/main.css" />
</head>
<body class="is-preload">
    <div id="page-wrapper">
        <!-- Header y demás contenido de tu página -->
        
        <!-- Formulario de Contacto -->
        <section>
            <form id="contactForm" runat="server">
                <div class="row gtr-50">
                    <div class="col-6 col-12-mobilep">
                        <asp:TextBox ID="txtName" runat="server" placeholder="Nombre" CssClass="form-control"></asp:TextBox>
                    </div>
                    <div class="col-6 col-12-mobilep">
                        <asp:TextBox ID="txtEmail" runat="server" TextMode="Email" placeholder="Email" CssClass="form-control"></asp:TextBox>
                    </div>
                    <div class="col-12">
                        <asp:TextBox ID="txtMessage" runat="server" TextMode="MultiLine" Rows="5" placeholder="Mensaje" CssClass="form-control"></asp:TextBox>
                    </div>
                    <div class="col-12">
                        <ul class="actions">
                            <li>
                                <asp:Button ID="btnSubmit" runat="server" Text="Enviar Mensaje" 
                                          CssClass="button alt" OnClick="btnSubmit_Click" />
                            </li>
                        </ul>
                    </div>
                </div>
            </form>
        </section>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.dropotron.min.js"></script>
    <script src="assets/js/browser.min.js"></script>
    <script src="assets/js/breakpoints.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>